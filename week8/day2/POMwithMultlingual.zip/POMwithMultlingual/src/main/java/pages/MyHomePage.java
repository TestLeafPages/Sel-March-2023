package pages;

import org.openqa.selenium.By;

import base.BaseClass;

public class MyHomePage extends BaseClass{
	
	
	public MyLeadsPage clickLeadButton() {
		driver.findElement(By.linkText(prop.getProperty("MyHomePage_Leads_LinkText"))).click();
		return new MyLeadsPage();
	}

}
