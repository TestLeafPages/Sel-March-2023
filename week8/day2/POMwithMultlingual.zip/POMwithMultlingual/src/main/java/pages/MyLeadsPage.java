package pages;

import org.openqa.selenium.By;

import base.BaseClass;

public class MyLeadsPage extends BaseClass{
	
	public CreateLeadPage clickCreateLead() {
		String CreateLeadLinTextValue = prop.getProperty("MyLeadsPage_CreatLead_LinkText");
		driver.findElement(By.linkText(CreateLeadLinTextValue)).click();
		return new CreateLeadPage();

	}
	

}
