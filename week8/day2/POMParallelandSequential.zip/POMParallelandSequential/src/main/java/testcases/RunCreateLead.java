package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunCreateLead extends BaseClass{

	@BeforeTest
	public void setValues() {
		ExcelFileName="CreateLeadExcel";
	}
	
	@Test(dataProvider="sendData")
	public void runCreateLead(String uName,String pWord,String cName,String fName,String lName) throws InterruptedException {
		LoginPage lp = new LoginPage(driver);
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.verifyWelcomePage()
		.clickCrmsfa()
		.clickLeadButton()
		.clickCreateLead()
		.enterCompanyName(cName)
		.enterFirstName(fName)
		.enterLastName(lName)
		.clickSubmitButton()
		.verifyViewLeadsPage();
	}
}
