package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import utils.ReadExcel;

public class BaseClass {

	public ChromeDriver driver;
	public String excelFileName;
	public static ExtentReports extent;
	public static ExtentTest test;
	
	public String testName, testDescription, testCategory, testAuthor; //null

	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);

	}
	
	@BeforeClass
	public void testDetails() {
		test = extent.createTest(testName, testDescription);
		test.assignCategory(testCategory);
		test.assignAuthor(testAuthor);	

	}
	
	
	
	public int takeSnap() throws IOException {
		
		int ranNum = (int) (Math.random()*9999999+1000000);
		
		File source = driver.getScreenshotAs(OutputType.FILE);
		File target = new File("./snaps/"+ranNum+".png"); //img126785.png
		FileUtils.copyFile(source, target);

		return ranNum; ///123456
	}
	
	
	public void reportStep(String stepInfo, String status) throws IOException {
		int randomNumber = takeSnap(); 
		
		if(status.equalsIgnoreCase("pass")) {
			test.pass(stepInfo, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/"+randomNumber+".png").build());
		} else {
			test.fail(stepInfo, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/"+randomNumber+".png").build());
			throw new RuntimeException("Please refer extent report for failure log");
		}

	}
	
	
	
	
	
	
	
	
	
	
	@AfterSuite
	public void stopReport() {
		extent.flush();
	}

	@BeforeMethod
	public void preCondition() {
		driver = new ChromeDriver();
		System.out.println(driver);
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}

	@AfterMethod
	public void postCondition() {
		driver.quit();
	}

	@DataProvider(indices = 0)
	public String[][] sendData() throws IOException {
		return ReadExcel.readExcel(excelFileName);

	}

}
