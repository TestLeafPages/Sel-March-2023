package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunLogin extends BaseClass{
	
	@BeforeTest
	public void setValues() {
		excelFileName="LoginExcel";
		testName = "login test";
		testDescription = "Login with positive data";
		testCategory = "Smoke";
		testAuthor = "Hari";
	}

	@Test(dataProvider = "sendData")
	public void verifyLogin(String uName,String pword) throws InterruptedException, IOException {
		System.out.println(driver);
	 LoginPage lp = new LoginPage(driver);
	 
	 lp.enterUsername(uName)
	 .enterPassword(pword)
	 .clickLoginButton();
	// .verifyWelcomePage();
	
     
	}
	
}
