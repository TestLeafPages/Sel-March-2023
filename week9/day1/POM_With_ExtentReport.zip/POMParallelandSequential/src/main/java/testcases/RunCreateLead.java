package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunCreateLead extends BaseClass{

	@BeforeTest
	public void setValues() {
		excelFileName="CreateLeadExcel";
		testName = "CreateLead test";
		testDescription = "Create lead with mandatory data data";
		testCategory = "functional";
		testAuthor = "Subraja";
	}
	
	@Test(dataProvider="sendData")
	public void runCreateLead(String uName,String pWord,String cName,String fName,String lName) throws InterruptedException, IOException {
		LoginPage lp = new LoginPage(driver);
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.verifyWelcomePage()
		.clickCrmsfa()
		.clickLeadButton()
		.clickCreateLead()
		.enterCompanyName(cName)
		.enterFirstName(fName)
		.enterLastName(lName)
		.clickSubmitButton()
		.verifyViewLeadsPage();
	}
}
